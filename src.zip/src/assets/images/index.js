const IMAGES = {

    allumni : require('./alumni_speakes.png'),
    connections : require('./connections.png'),
    ddu_speaks : require('./ddu_speakes.png'),
    dentistry : require('./dentistry.png'),
    fiction :  require('./fiction.png'),
    interview : require('./interview.png'),
    more_content : require('./more_content.png'),
    non_tech : require('./non_tech.png'),
    open_letter : require('./open_letter.png'),
    past_year_papers : require('./past_year_papers.png'),
    tech_it_easy : require('./tech_it_easy.png'),
    tech : require('./tech.png'),
    verses :  require('./verses.png'),
    writers_launge : require('./writers_launge.png'),
    gujarati : require('./gujarati.png'),
    dclogo :  require('./dclogo.png'),

 
};
export default IMAGES;
