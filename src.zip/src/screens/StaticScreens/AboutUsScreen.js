import React,{ Component ,PropType } from 'react';
import {FlatList,ImageBackground,View,ScrollView,Image,StyleSheet, Dimensions,ActivityIndicator} from 'react-native';
import { WebView } from 'react-native-webview';
import {Title,Card,Text,Left,Right,Button,Body,Container,Icon, Row} from 'native-base';
import {Header} from 'react-native-elements'
export default class AboutUsScreen extends Component{
  
    constructor(props) {
        super(props);
        this.state = { visible: true };
    }
     
    hideSpinner() {
        this.setState({ visible: false });
    }
    
	render(){
        
        const params = "https://dduconnect.in/about-us";
       // console.log(params);
    return(
    
        <View style={{ flex:1,justifyContent:'center',marginTop:-20}}>
        <Header backgroundColor='fff'>
          <Button transparent onPress={this.props.navigation.toggleDrawer}>
            <Icon name='menu' />
          </Button>
          <Text style={{fontFamily:'Montserrat-Bold',fontWeight:'900'}}> About Us </Text>
          </Header>  
            
            <WebView
            style={{marginTop:-129,zIndex:-10}}
              source={{uri: params}}
              onLoad={() => this.hideSpinner()}
              javaScriptEnabled={true}
             
              pagingEnabled
              scalesPageToFit={true}
              containerStyle={{flex:1,alignItems:'stretch'}}
            />

        {this.state.visible && (
          <ActivityIndicator
            style={{ position: "absolute",flex:1,justifyContent:'center',alignItems:'center',alignSelf:'center' }}
            size="large"
          />
        )}
        </View>
        
        
        
    );  
}

}

const styles = StyleSheet.create({
    stylOld: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    },
    styleNew: {
      flex: 1,
    },
    WebViewStyle: {
      justifyContent: 'center',
      alignItems: 'center',
      flex: 1,
      marginTop: 40,
    },
    ActivityIndicatorStyle: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      position: 'absolute',
    },
  });