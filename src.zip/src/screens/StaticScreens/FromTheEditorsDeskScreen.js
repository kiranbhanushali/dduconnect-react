import React  , { Component ,PropType } from 'react';
import { View ,Text ,Button} from 'react-native';

export default class FromTheEditorsDeskScreen extends Component{
static navigationOptions = {
    drawerLabel: 'FromTheEditorsDesk',
    
  };
	render(){
		return <Text> FromTheEditorsDeskScreen </Text>
	}

}