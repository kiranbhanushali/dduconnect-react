import React  , { Component ,PropType } from 'react';
import { View ,Text ,} from 'react-native';
import RootStackNavigator from './screens/Navigation/RootStackNavigator'



export default class Index extends Component{
	
	 

render(){ 
    return <RootStackNavigator />
	

   }//render

}